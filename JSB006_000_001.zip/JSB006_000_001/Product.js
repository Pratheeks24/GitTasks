 function productNumbers(firstNumber, secondNumber) {
         return  firstNumber * secondNumber;
        }
        const product = productNumbers(4, 6);
        console.log(product); 
         document.getElementById("productId").innerText = product;